# Birthday Surprise Telegram Bot
Бот-сюрприз для дня рождения с заданиями, комплиментами и подарком 🎁